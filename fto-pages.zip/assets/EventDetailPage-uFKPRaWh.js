import{j as e}from"./vendor-radix-D-ExlyMv.js";import{n as f,B as n,N as g,b as u,d as v,e as c,f as x,H as N,g as d,h,i as b,j as w,C as F,G as p,M as y,E as k,l as E}from"./index-DrcNSk-K.js";import{f as C}from"./formatContent-B6o_b9iA.js";import"./vendor-charts-DF4E0OgG.js";import"./vendor-motion-pOD7n95U.js";function $({eventId:j,events:l,onBack:r,onNavigate:i=()=>{},onCommunityClick:o}){const t=(l&&l.length>0?l:f).find(s=>s.id===j);if(!t)return e.jsx("div",{className:"min-h-screen bg-[#FCF8F3] flex items-center justify-center",children:e.jsxs("div",{className:"text-center space-y-4",children:[e.jsx("p",{className:"text-xl text-[#101010]/60",children:"Event not found"}),e.jsx(n,{onClick:r,className:"bg-[#7935F8] text-white rounded-full",children:"Back to Events"})]})});const m=s=>new Date(s).toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"});return e.jsxs("div",{className:"min-h-screen bg-[#FCF8F3] flex flex-col",children:[e.jsx("div",{className:"fixed top-0 left-0 right-0 z-50 pointer-events-none",children:e.jsx("div",{className:"pointer-events-auto",children:e.jsx(g,{onNavigate:i,onCommunityClick:o,currentPage:"events"})})}),e.jsxs("div",{className:"flex-1",children:[e.jsx("div",{className:"pt-32 pb-4 px-6",children:e.jsx("div",{className:"max-w-5xl mx-auto",children:e.jsx(u,{children:e.jsxs(v,{className:"text-sm font-medium",children:[e.jsx(c,{children:e.jsxs(x,{onClick:()=>i("home"),className:"flex items-center gap-2 cursor-pointer hover:text-[#7935F8] transition-colors text-[#101010]/40 font-normal",children:[e.jsx(N,{className:"w-4 h-4 -mt-0.5"}),"Home"]})}),e.jsx(d,{className:"text-[#101010]/20 scale-75",children:e.jsx(h,{className:"w-4 h-4"})}),e.jsx(c,{children:e.jsx(x,{onClick:r,className:"cursor-pointer hover:text-[#7935F8] transition-colors text-[#101010]/40 font-normal",children:"Events"})}),e.jsx(d,{className:"text-[#101010]/20 scale-75",children:e.jsx(h,{className:"w-4 h-4"})}),e.jsx(c,{children:e.jsx(b,{className:"line-clamp-1 text-[#101010] font-normal max-w-[200px] md:max-w-md",children:t.title})})]})})})}),e.jsx("div",{className:"px-6 pb-8",children:e.jsx("div",{className:"max-w-5xl mx-auto",children:e.jsxs(n,{onClick:r,variant:"ghost",className:"group h-auto p-0 hover:bg-transparent text-[#101010] font-medium hover:text-[#7935F8] transition-colors gap-2",children:[e.jsx(w,{className:"w-4 h-4 transition-transform group-hover:-translate-x-1"}),"Back to Events"]})})}),t.image&&e.jsx("div",{className:"px-6 pb-8",children:e.jsx("div",{className:"max-w-5xl mx-auto",children:e.jsx("div",{className:"relative rounded-3xl overflow-hidden aspect-[16/9] bg-[#101010]/5",children:e.jsx("img",{src:t.image,alt:t.title,className:"w-full h-full object-cover"})})})}),e.jsx("article",{className:"px-6 pb-20",children:e.jsxs("div",{className:"max-w-3xl mx-auto",children:[e.jsx("h1",{className:"text-3xl md:text-4xl lg:text-5xl text-[#101010] mb-8 mt-2 font-semibold tracking-tight leading-[1.1]",children:t.title}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10 pb-10 border-b border-[#101010]/10",children:[e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-[#7935F8]/10 flex items-center justify-center flex-shrink-0",children:e.jsx(F,{className:"w-5 h-5 text-[#7935F8]"})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-[#101010]",children:"Date & Time"}),e.jsx("p",{className:"text-[#101010]/70 text-sm mt-1",children:m(t.startDate)}),t.endDate&&e.jsxs("p",{className:"text-[#101010]/70 text-sm",children:["to ",m(t.endDate)]})]})]}),e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-[#7935F8]/10 flex items-center justify-center flex-shrink-0",children:t.location.type==="online"?e.jsx(p,{className:"w-5 h-5 text-[#7935F8]"}):e.jsx(y,{className:"w-5 h-5 text-[#7935F8]"})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-[#101010]",children:"Location"}),e.jsx("p",{className:"text-[#101010]/70 text-sm mt-1 capitalize",children:t.location.type==="online"?"Online Event":`${t.location.city}, ${t.location.country}`})]})]}),t.organizer&&e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-[#7935F8]/10 flex items-center justify-center flex-shrink-0",children:e.jsx(p,{className:"w-5 h-5 text-[#7935F8]"})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-[#101010]",children:"Organizer"}),e.jsx("p",{className:"text-[#101010]/70 text-sm mt-1",children:t.organizer})]})]}),t.price&&e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-[#7935F8]/10 flex items-center justify-center flex-shrink-0",children:e.jsx("span",{className:"text-[#7935F8] font-bold text-sm",children:"$"})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-[#101010]",children:"Price"}),e.jsx("p",{className:"text-[#101010]/70 text-sm mt-1",children:typeof t.price=="object"&&"amount"in t.price?`${String(t.price.amount).startsWith("$")||String(t.price.amount).startsWith("€")?"":"€"}${t.price.amount}`:t.price.type==="free"?"Free":t.price.type==="donation"?"Donation":"Paid"})]})]})]}),e.jsxs("div",{className:"prose prose-lg max-w-none mb-12",children:[e.jsx("h3",{className:"text-2xl font-semibold text-[#101010] mb-4",children:"About this Event"}),e.jsx("style",{children:`
                .event-content p {
                  margin-bottom: 1.25rem;
                  line-height: 1.85;
                }
                .event-content p:empty { display: none; }
                .event-content h2 {
                  font-weight: 600;
                  font-size: 1.5rem;
                  margin-top: 2.5rem;
                  margin-bottom: 0.75rem;
                  color: #101010;
                }
                .event-content h3 {
                  font-weight: 600;
                  font-size: 1.2rem;
                  margin-top: 2rem;
                  margin-bottom: 0.5rem;
                  color: #101010;
                }
                .event-content strong { color: #101010; font-weight: 600; }
                .event-content ul {
                  margin: 0.5rem 0 1rem 0;
                  padding-left: 0;
                  list-style: none;
                }
                .event-content li {
                  position: relative;
                  padding-left: 1.75rem;
                  margin-bottom: 0.2rem;
                  line-height: 1.65;
                }
                .event-content li::before {
                  content: '';
                  position: absolute;
                  left: 0.25rem;
                  top: 0.65rem;
                  width: 5px;
                  height: 5px;
                  border-radius: 50%;
                  background: #7935F8;
                }
              `}),e.jsx("div",{className:"event-content leading-relaxed text-[#101010]/90 font-light text-lg",dangerouslySetInnerHTML:{__html:C(t.description)}})]}),t.tags&&t.tags.length>0&&e.jsx("div",{className:"pt-8 border-t border-[#101010]/10 mb-8",children:e.jsx("div",{className:"flex flex-wrap gap-2",children:t.tags.map((s,a)=>e.jsx("span",{className:"px-3 py-1 rounded-full text-sm",style:{backgroundColor:a%3===0?"#B197FF20":a%3===1?"#1ADF8320":"#7935F820",color:a%3===0?"#7935F8":a%3===1?"#066237":"#7935F8",fontWeight:500},children:s},a))})}),e.jsx("div",{className:"pt-4",children:t.website?e.jsxs(n,{className:"w-full sm:w-auto bg-[#7935F8] hover:bg-[#6929d6] text-white h-12 text-base rounded-full px-8 gap-2 shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5",onClick:()=>window.open(t.website,"_blank"),children:["Visit Event Website",e.jsx(k,{className:"w-4 h-4"})]}):e.jsx(n,{disabled:!0,className:"w-full sm:w-auto h-12 rounded-full px-8",children:"Coming Soon"})})]})})]}),e.jsx(E,{onNavigate:i,onCommunityClick:o})]})}export{$ as EventDetailPage};
