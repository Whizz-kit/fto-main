import{a as h,j as e}from"./vendor-radix-D-ExlyMv.js";import{x as k,B as o,j as c,o as S,N as B,b as C,d as L,e as m,f as p,H as E,g,h as u,i as z,y as v,a as f,k as A,l as H}from"./index-DrcNSk-K.js";import{f as R}from"./formatContent-B6o_b9iA.js";import{S as T}from"./share-2-B7K6Yxes.js";import"./vendor-charts-DF4E0OgG.js";import"./vendor-motion-pOD7n95U.js";function _({articleId:d,articles:w,onBack:a,onNavigate:i,onCommunityClick:n,onArticleClick:j}){const[t,F]=h.useState(null),[b,y]=h.useState([]),x=w||k;if(h.useEffect(()=>{const s=x.find(l=>l.id===d);if(s){F(s);const l=x.filter(N=>N.id!==d&&N.category===s.category).slice(0,2);y(l)}},[d,x]),!t)return e.jsx("div",{className:"min-h-screen flex items-center justify-center bg-[#FCF8F3]",children:e.jsxs("div",{className:"text-center space-y-4",children:[e.jsx("p",{className:"text-muted-foreground",children:"Article not found"}),e.jsxs(o,{onClick:a,variant:"outline",className:"rounded-full",children:[e.jsx(c,{className:"w-4 h-4 mr-2"}),"Back to Explore"]})]})});const r=S.find(s=>s.slug===t.category||s.title===t.category);return e.jsxs("div",{className:"min-h-screen bg-[#FCF8F3] flex flex-col",children:[e.jsx("div",{className:"fixed top-0 left-0 right-0 z-50 pointer-events-none",children:e.jsx(B,{onNavigate:i||(()=>{}),onCommunityClick:n,currentPage:"explore"})}),e.jsxs("main",{className:"flex-1",children:[e.jsx("div",{className:"pt-32 pb-4 px-6",children:e.jsx("div",{className:"max-w-5xl mx-auto",children:e.jsx(C,{children:e.jsxs(L,{className:"text-sm font-medium",children:[e.jsx(m,{children:e.jsxs(p,{onClick:()=>i?.("home"),className:"flex items-center gap-2 cursor-pointer hover:text-[#7935F8] transition-colors text-[#101010]/40 font-normal",children:[e.jsx(E,{className:"w-4 h-4 -mt-0.5"}),"Home"]})}),e.jsx(g,{className:"text-[#101010]/20 scale-75",children:e.jsx(u,{className:"w-4 h-4"})}),e.jsx(m,{children:e.jsx(p,{onClick:()=>i?.("explore"),className:"cursor-pointer hover:text-[#7935F8] transition-colors text-[#101010]/40 font-normal",children:"Explore"})}),r&&e.jsxs(e.Fragment,{children:[e.jsx(g,{className:"text-[#101010]/20 scale-75",children:e.jsx(u,{className:"w-4 h-4"})}),e.jsx(m,{children:e.jsx(p,{onClick:a,className:"cursor-pointer hover:text-[#7935F8] transition-colors text-[#101010]/40 font-normal",children:r.title})})]}),e.jsx(g,{className:"text-[#101010]/20 scale-75",children:e.jsx(u,{className:"w-4 h-4"})}),e.jsx(m,{children:e.jsx(z,{className:"line-clamp-1 text-[#101010] font-normal max-w-[200px] md:max-w-md",children:t.title})})]})})})}),e.jsx("div",{className:"px-6 pb-8",children:e.jsx("div",{className:"max-w-5xl mx-auto",children:e.jsxs(o,{onClick:a,variant:"ghost",className:"group h-auto p-0 hover:bg-transparent text-[#101010] font-medium hover:text-[#7935F8] transition-colors gap-2",children:[e.jsx(c,{className:"w-4 h-4 transition-transform group-hover:-translate-x-1"}),"Back to ",r?.title||"Explore"]})})}),e.jsxs("div",{className:"max-w-5xl mx-auto px-6 pb-16",children:[e.jsx("div",{className:"aspect-[21/9] rounded-3xl overflow-hidden shadow-2xl mb-8",children:e.jsx(v,{src:t.image||"https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=1200&h=400&fit=crop",alt:t.title,className:"w-full h-full object-cover"})}),e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-wrap gap-2",children:[r&&e.jsx(f,{className:"bg-[#7935F8] text-white border-0 rounded-full px-4 py-1.5",children:r.title}),t.tags.slice(0,4).map((s,l)=>e.jsx(f,{variant:"outline",className:"rounded-full px-4 py-1.5 border-[#7935F8]/30 text-[#7935F8]",children:s},l))]}),e.jsx("h1",{className:"text-3xl md:text-4xl lg:text-5xl text-[#101010] font-semibold tracking-tight leading-[1.1]",children:t.title}),t.excerpt&&e.jsx("p",{className:"text-lg md:text-xl text-[#101010]/50 leading-relaxed max-w-3xl",children:t.excerpt}),e.jsxs("div",{className:"flex items-center gap-3 text-sm text-[#101010]/40 pt-2",children:[t.readTime&&e.jsx("span",{children:t.readTime}),t.publishedAt&&e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"w-1 h-1 rounded-full bg-[#101010]/20"}),e.jsx("span",{children:new Date(t.publishedAt).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})})]})]})]}),e.jsx("hr",{className:"border-[#101010]/5 my-10"}),e.jsxs("article",{className:"max-w-3xl",children:[e.jsx("style",{children:`
              .article-content {
                font-size: 1.0625rem;
                line-height: 1.85;
                color: rgba(16, 16, 16, 0.85);
              }
              .article-content h2 {
                font-weight: 600;
                font-size: 1.5rem;
                margin-top: 2.5rem;
                margin-bottom: 0.75rem;
                color: #101010;
                letter-spacing: -0.01em;
              }
              .article-content h3 {
                font-weight: 600;
                font-size: 1.2rem;
                margin-top: 2rem;
                margin-bottom: 0.5rem;
                color: #7935F8;
                letter-spacing: -0.01em;
              }
              .article-content h4 {
                font-weight: 600;
                font-size: 1.05rem;
                margin-top: 1.5rem;
                margin-bottom: 0.5rem;
                color: #101010;
              }
              .article-content p {
                margin-bottom: 1.25rem;
                line-height: 1.85;
              }
              .article-content ul, .article-content ol {
                margin: 0.5rem 0 1rem 0;
                padding-left: 0;
                list-style: none;
              }
              .article-content ul + ul, .article-content ol + ol,
              .article-content ul + p + ul, .article-content ol + p + ol {
                margin-top: 0;
              }
              .article-content .w-richtext,
              .article-content [class*="rich-text"] {
                all: unset;
              }
              .article-content li {
                position: relative;
                padding-left: 1.75rem;
                margin-bottom: 0.2rem;
                margin-top: 0;
                line-height: 1.6;
              }
              .article-content li:last-child {
                margin-bottom: 0;
              }
              .article-content li p,
              .article-content li div,
              .article-content li span {
                margin: 0 !important;
                padding: 0 !important;
                display: inline;
              }
              .article-content li br {
                display: none;
              }
              .article-content ul + p:empty,
              .article-content ol + p:empty {
                display: none;
              }
              .article-content li::before {
                content: '';
                position: absolute;
                left: 0.25rem;
                top: 0.65rem;
                width: 5px;
                height: 5px;
                border-radius: 50%;
                background: #7935F8;
              }
              .article-content strong {
                color: #101010;
                font-weight: 600;
              }
              .article-content p:first-child {
                font-size: 1.125rem;
                line-height: 1.8;
                color: #101010;
              }
            `}),e.jsx("div",{className:"article-content",dangerouslySetInnerHTML:{__html:R(t.content)}})]}),e.jsxs("div",{className:"pt-8 border-t border-[#101010]/10 flex flex-col sm:flex-row items-center justify-between gap-4 mt-8",children:[e.jsxs(o,{onClick:a,variant:"outline",className:"rounded-full gap-2 border-[#7935F8]/30 text-[#7935F8] hover:bg-[#7935F8]/5",children:[e.jsx(c,{className:"w-4 h-4"}),"Back to ",r?.title||"Explore"]}),e.jsxs(o,{variant:"outline",className:"rounded-full gap-2 border-[#7935F8]/30 text-[#7935F8] hover:bg-[#7935F8]/5",onClick:()=>{navigator.share?navigator.share({title:t.title,text:t.excerpt,url:window.location.href}):(navigator.clipboard.writeText(window.location.href),alert("Link copied to clipboard!"))},children:[e.jsx(T,{className:"w-4 h-4"}),"Share Article"]})]}),e.jsx("div",{className:"pt-12",children:e.jsx(A,{onSignUpClick:n,onLoginClick:n})}),b.length>0&&e.jsxs("div",{className:"pt-12 mt-12 border-t border-[#101010]/10",children:[e.jsx("h2",{className:"text-2xl md:text-3xl text-[#101010] mb-6 font-semibold",children:"You Might Also Like"}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:b.map(s=>e.jsxs("article",{onClick:()=>{j&&j(s.id,s.category)},className:"group cursor-pointer bg-white rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 border border-[#101010]/10",children:[e.jsx("div",{className:"aspect-[16/9] overflow-hidden",children:e.jsx(v,{src:s.image||"https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&h=450&fit=crop",alt:s.title,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"})}),e.jsxs("div",{className:"p-6 space-y-3",children:[r&&e.jsx(f,{className:"bg-[#7935F8] text-white border-0 rounded-full px-3 py-1",children:r.title}),e.jsx("h3",{className:"text-xl text-[#101010] line-clamp-2 group-hover:text-[#7935F8] transition-colors font-semibold",children:s.title}),e.jsx("p",{className:"text-muted-foreground text-sm line-clamp-2 leading-relaxed",children:s.excerpt}),e.jsxs("div",{className:"flex items-center gap-2 text-[#7935F8] text-sm pt-2",children:[e.jsx("span",{children:"Read article"}),e.jsx(c,{className:"w-3 h-3 rotate-180 group-hover:translate-x-1 transition-transform"})]})]})]},s.id))})]})]})]}),e.jsx(H,{onNavigate:i,onCommunityClick:n})]})}export{_ as KnowledgeArticleDetail};
